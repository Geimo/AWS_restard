"""
Your module description
"""
myString = "This is a string."
print(myString)