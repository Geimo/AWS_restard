"""
Your module description
"""
myString = "This is a string."
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))
#Ejercicio 2
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)
name = input("Geissel)
print(name)
name = input("What is your name? ")
print(name)