Lista_numbers = [3, 2, 5, 1, 2, 4, 6, 1, 3, 5, 7]

lista_sin_duplicados = 
list(set(lista_numeros))